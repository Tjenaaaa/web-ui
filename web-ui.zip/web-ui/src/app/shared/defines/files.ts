export class Configuration {
  static readonly WORDLIST = 0;
  static readonly RULE = 1
  static readonly OTHER = 2
}
