/**
 * Agent Stats Constants
**/

export class ASC {

  public static GPU_TEMP = 1;
  public static GPU_UTIL = 2;
  public static CPU_UTIL = 3;

}

