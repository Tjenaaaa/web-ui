export interface AccessGroup {
  accessGroupId: number;
  groupName: string;
}
