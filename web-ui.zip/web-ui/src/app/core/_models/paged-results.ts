export interface IPagedResults<T> {
  totalRecords: number;
  results: T;
}
