export interface Hashtype {
    hashTypeId: number;
    description: string;
    isSalted: boolean;
    isSlowHash: boolean;
}
