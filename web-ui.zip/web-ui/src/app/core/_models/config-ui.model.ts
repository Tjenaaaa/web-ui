export class IStorage {
  constructor(
    private _timefmt: string,
    private _enablebrain: number,
    private _halias: string,
    private _bchars: string,
    private _chunkt: string,
    private _statimer: string,
    private _timestamp: number,
    private _expiresin: number,
  ) {}

}

export class UIGConfig {
  constructor(

  ) {}

}

