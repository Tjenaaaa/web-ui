export interface Userf {
    userId: any
    username: any;
}

export class User{
    query:any;
    user: Userf[];

}

// export class User{
//     public userId: number;
//     public username: string;
//     public registeredSince: number;
//     public lastLoginDate: number;
//     public email: string;
//     public isValid: number;
//     public sessionLifetime: number;
//     public rightGroupId: string;

// }
